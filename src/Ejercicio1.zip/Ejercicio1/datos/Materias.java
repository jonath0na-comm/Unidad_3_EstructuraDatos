/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicio1.datos;

/**
 *
 * @author Jonat
 */
public class Materias {
    String nombre;
    int calificaciòn;
    int semestre;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCalificaciòn() {
        return calificaciòn;
    }

    public void setCalificaciòn(int calificaciòn) {
        this.calificaciòn = calificaciòn;
    }

    public int getSemestre() {
        return semestre;
    }

    public void setSemestre(int semestre) {
        this.semestre = semestre;
    }
}
